/*
 * autor   : Ingrid Farkaš
 * projekat: Ptica
 * DetermineID.java : koristi se u DelServlet.java
 */
package delservlet;

import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;

public class DetermineID {
    
    // za autora sa imenom ime_aut vraća author id
    public String odrediBrAut(String ime_aut, Statement stmt) { 
        try {
            // formiranje upita SELECT au_id FROM author WHERE au_name='...';
            String braut = ""; // broj autora
            
            // formiranje upita
            String rs_upit = "SELECT au_id "; 
            rs_upit += "FROM author WHERE au_name='" + ime_aut + "'";
            rs_upit += ";";   
            
            // izvršavanje upita
            ResultSet rs = stmt.executeQuery(rs_upit);
            
            // ako rezultat upita sadrži slogove, nalazim broj autora 
            if (rs.next()) 
                braut = rs.getString("au_id");
            return braut;
            
        } catch (SQLException ex) {
            return ""; // ako je došlo do izuzetka vraćam broj autora = ""
        }
    }
}
